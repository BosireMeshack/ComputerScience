/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package hospitalupgrade;
import hospitalupgrade.PatientState;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author meshagwe
 */
public class PatientTest {
    
    public PatientTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getName method, of class Patient.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Patient instance = new Patient("John", 7);
        String expResult = "John";
        String result = instance.getName();
        assertEquals(expResult, result);
   
    }

    /**
     * Test of getSeverityLevel method, of class Patient.
     */
    @Test
    public void testGetSeverityLevel() {
        System.out.println("getSeverityLevel");
        Patient instance = new Patient("John", 7);;
        int expResult = 7;
        int result = instance.getSeverityLevel();
        assertEquals(expResult, result);
      
    }

    /**
     * Test of setStatus method, of class Patient.
     */
    @Test
    public void testSetStatus() {
        System.out.println("setStatus");
        boolean status = false;
        Patient instance = new Patient("John", 7);;
        instance.setStatus(status);
        
    }

    /**
     * Test of getStatus method, of class Patient.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        Patient instance = new Patient("John", 7);;
        boolean expResult = false;
        boolean result = instance.getStatus();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of reduceSeverity method, of class Patient.
     */
    @Test
    public void testReduceSeverity() {
        System.out.println("reduceSeverity");
        int amount = 4;
        Patient instance = new Patient("John", 7);;
        instance.reduceSeverity(amount);
    }

    /**
     * Test of updateState method, of class Patient.
     */
    @Test
    public void testUpdateState() {
        System.out.println("updateState");
        PatientState newState = PatientState.ADMITTED;
        Patient instance = new Patient("John", 7);
        instance.updateState(newState);
        
    }

    /**
     * Test of getState method, of class Patient.
     */
    @Test
    public void testGetState() {
        System.out.println("getState");
        Patient instance = new Patient("John", 7);
        PatientState expResult = PatientState.WAITING;
        PatientState result = instance.getState();
        assertEquals(expResult, result);
      
    }
    
}
