/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package hospitalupgrade;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author meshagwe
 */
public class AmbulanceTest {
    
    public AmbulanceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getStatus method, of class Ambulance.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        Ambulance instance = new Ambulance("A1");
        String expResult = "available";
        String result = instance.getStatus();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of changeStatus method, of class Ambulance.
     */
    @Test
    public void testChangeStatus() {
        System.out.println("changeStatus");
        String newStatus = "en route";
        Ambulance instance = new Ambulance("A1");
        instance.changeStatus(newStatus);
    
    }

    /**
     * Test of setDestinationHospital method, of class Ambulance.
     */
    @Test
    public void testSetDestinationHospital() {
        System.out.println("setDestinationHospital");
        Hospital h = new Hospital("City_Medical_Center", 2);
        Ambulance instance = new Ambulance("A1");
        instance.setDestinationHospital(h);
        
    }

    /**
     * Test of getId method, of class Ambulance.
     */
    @Test
    public void testGetId() {
        System.out.println("getId");
        Ambulance instance = new Ambulance("A1");
        String expResult = "A1";
        String result = instance.getId();
        assertEquals(expResult, result);
        
    }
    
}
