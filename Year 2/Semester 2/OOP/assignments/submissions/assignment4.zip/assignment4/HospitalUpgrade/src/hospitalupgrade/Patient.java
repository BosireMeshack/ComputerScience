/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalupgrade;
import hospitalupgrade.PatientState;


/**
 *
 * @author meshagwe
 */
class Patient {
    private String name;
    private int severityLevel;
    private boolean status;
    private PatientState state = PatientState.WAITING;

    public Patient(String name, int severityLevel) {
        this.name = name;
        this.severityLevel = severityLevel;
    }

    public String getName() {
        return name;
    }

    public int getSeverityLevel() {
        return severityLevel;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public boolean getStatus() {
        return status;
    }

    public void reduceSeverity(int amount) {
        this.severityLevel = Math.max(0, this.severityLevel - amount);
        if (this.severityLevel == 0) {
            this.status = true;
            this.state = PatientState.RECOVERED;
        }
    }

    public void updateState(PatientState newState) {
        this.state = newState;
    }

    public PatientState getState() {
        return this.state;
    }
}
