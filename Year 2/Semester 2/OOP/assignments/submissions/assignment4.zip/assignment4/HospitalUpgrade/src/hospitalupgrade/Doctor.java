/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalupgrade;
import hospitalupgrade.PatientState;
/**
 *
 * @author meshagwe
 */
class Doctor {
    private String name;
    private int efficiencyLevel;

    public Doctor(String name, int efficiencyLevel) {
        this.name = name;
        this.efficiencyLevel = efficiencyLevel;
    }

    public void treat(Patient p) {
        if (p == null) throw new IllegalArgumentException("Patient cannot be null");
        int reduction = (p.getSeverityLevel() > 5) ? (int)(efficiencyLevel * 1.5) : efficiencyLevel;
        p.reduceSeverity(reduction);
        p.updateState(PatientState.UNDER_TREATMENT);
    }
}
