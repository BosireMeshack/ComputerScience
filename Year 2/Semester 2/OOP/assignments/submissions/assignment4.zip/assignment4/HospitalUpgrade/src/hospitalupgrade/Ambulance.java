/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalupgrade;

/**
 *
 * @author meshagwe
 */
class Ambulance {
    private String id;
    private String status;
    private Hospital destinationHospital;

    public Ambulance(String id) {
        this.id = id;
        this.status = "available";
    }

    public String getStatus() {
        return status;
    }

    public void changeStatus(String newStatus) {
        if (newStatus == null || newStatus.isEmpty()) throw new IllegalArgumentException("Invalid status");
        this.status = newStatus;
    }

    public void setDestinationHospital(Hospital h) {
        if (h == null) throw new IllegalArgumentException("Hospital must not be null");
        this.destinationHospital = h;
    }

    public String getId() {
        return id;
    }
}
