/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hospitalupgrade;

/**
 *
 * @author meshagwe
 */
public class Main {
    public static void main(String[] args) {
        try {
            // Hospitals
            Hospital h1 = new Hospital("City_Medical_Center", 2);
            Hospital h2 = new Hospital("General_Hospital", 3);

            // Doctors
            Doctor d1 = new Doctor("Dr_Smith", 5);
            Doctor d2 = new Doctor("Dr_Adam", 3);
            Doctor d3 = new Doctor("Dr_Farizi", 8);

            // Ambulances
            Ambulance amb1 = new Ambulance("A1");
            Ambulance amb2 = new Ambulance("A2");
            Ambulance amb3 = new Ambulance("A3");
            Ambulance amb4 = new Ambulance("A4");

            // Patients
            Patient p1 = new Patient("John", 7);
            Patient p2 = new Patient("Alice", 4);
            Patient p3 = new Patient("Bob", 9);
            Patient p4 = new Patient("Eve", 6);
            Patient p5 = new Patient("Charlie", 3);

            // Register doctors to hospitals
            h1.registerPatient(p1);
            h1.registerPatient(p2);
            h2.registerPatient(p3);

            // EAS
            Hospital[] hospitals = {h1, h2};
            Ambulance[] ambulances = {amb1, amb2, amb3, amb4};
            EAS system = new EAS(hospitals, ambulances);

            // Respond to new emergencies
            system.respondToEmergency(p4);
            system.respondToEmergency(p5);

            // Simulate treatment
            d1.treat(p1);
            d2.treat(p2);
            d3.treat(p3);

            // Output states
            System.out.println(p1.getName() + " State: " + p1.getState());
            System.out.println(p2.getName() + " State: " + p2.getState());
            System.out.println(p3.getName() + " State: " + p3.getState());

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
}
