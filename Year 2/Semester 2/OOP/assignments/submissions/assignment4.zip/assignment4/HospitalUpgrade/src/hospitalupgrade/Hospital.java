/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalupgrade;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author meshagwe
 */
class Hospital {

    private String name;
    private int capacity;
    private int maxCapacity;
    private List<Patient> patients = new ArrayList<>();
    private List<Doctor> doctors = new ArrayList<>();

    public Hospital(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.maxCapacity = capacity;
    }

    public boolean hasSpace() {
        return patients.size() < capacity;
    }

    public boolean tryOverflowCapacity() {
        if (capacity == maxCapacity) {
            capacity = (int) (capacity * 1.25);
            return true;
        }
        return false;
    }

    public void registerPatient(Patient p) {
        if (p == null) throw new IllegalArgumentException("Patient must not be null");
        if (!hasSpace()) throw new IllegalStateException("No space in hospital");
        patients.add(p);
    }

    public int getPatientCount() {
        return patients.size();
    }

    public String getName() {
        return name;
    }
}