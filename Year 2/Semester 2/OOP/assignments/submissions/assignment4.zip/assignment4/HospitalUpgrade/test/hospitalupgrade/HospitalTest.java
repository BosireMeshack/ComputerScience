/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package hospitalupgrade;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author meshagwe
 */
public class HospitalTest {
    
    public HospitalTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of hasSpace method, of class Hospital.
     */
    @Test
    public void testHasSpace() {
        System.out.println("hasSpace");
        Hospital instance = new Hospital("City_Medical_Center", 2);
        boolean expResult = true;
        boolean result = instance.hasSpace();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of tryOverflowCapacity method, of class Hospital.
     */
    @Test
    public void testTryOverflowCapacity() {
        System.out.println("tryOverflowCapacity");
        Hospital instance = new Hospital("City_Medical_Center", 2);
        boolean expResult = true;
        boolean result = instance.tryOverflowCapacity();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of registerPatient method, of class Hospital.
     */
    @Test
    public void testRegisterPatient() {
        System.out.println("registerPatient");
        Patient p = new Patient("John", 7);
        Hospital instance = new Hospital("City_Medical_Center", 2);
        instance.registerPatient(p);
      
    }

    /**
     * Test of getPatientCount method, of class Hospital.
     */
    @Test
    public void testGetPatientCount() {
        System.out.println("getPatientCount");
        Hospital instance = new Hospital("City_Medical_Center", 2);
        int expResult = 0;
        int result = instance.getPatientCount();
        assertEquals(expResult, result);
       
    }

    /**
     * Test of getName method, of class Hospital.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Hospital instance = new Hospital("City_Medical_Center", 2);;
        String expResult = "City_Medical_Center";
        String result = instance.getName();
        assertEquals(expResult, result);
     
    }
    
}
