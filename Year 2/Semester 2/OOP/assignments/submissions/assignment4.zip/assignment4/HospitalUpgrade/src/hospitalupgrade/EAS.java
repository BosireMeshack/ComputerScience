/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospitalupgrade;
import hospitalupgrade.PatientState;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author meshagwe
 */
public class EAS {
    private List<Hospital> hospitals = new ArrayList<>();
    private List<Ambulance> ambulances = new ArrayList<>();

    public EAS(Hospital[] hospitals, Ambulance[] ambulances) {
        if (hospitals != null) {
            this.hospitals.addAll(Arrays.asList(hospitals));
        }
        if (ambulances != null) {
            this.ambulances.addAll(Arrays.asList(ambulances));
        }
    }

    EAS(Hospital[] hospital) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
   
    public void registerHospital(Hospital h) {
        if (h == null) throw new IllegalArgumentException("Hospital cannot be null");
        if (hospitals.contains(h)) throw new IllegalStateException("Hospital is already registered");
        hospitals.add(h);
    }

    public void registerAmbulance(Ambulance a) {
        if (a == null) throw new IllegalArgumentException("Ambulance cannot be null");
        if (ambulances.contains(a)) throw new IllegalStateException("Ambulance already registered");
        ambulances.add(a);
    }

    /**
     * Handles an emergency alert and attempts to assign a patient to the best hospital.
     */
    public void respondToEmergency(Patient p) {
        if (p == null) throw new IllegalArgumentException("Patient cannot be null");

        Hospital bestHospital = findHospitalWithSpace();
        if (bestHospital == null) {
            for (Hospital h : hospitals) {
                boolean overflowed = h.tryOverflowCapacity();
                if (overflowed && h.hasSpace()) {
                    bestHospital = h;
                    break;
                }
            }
        }

        if (bestHospital == null) {
            System.out.println("System overload: No hospital can accept the patient now. Adding to waitlist...");
            return; 
        }

        Ambulance availableAmb = ambulances.stream()
                .filter(a -> a.getStatus().equalsIgnoreCase("available"))
                .findFirst()
                .orElse(null);

        if (availableAmb == null) {
            System.out.println("No ambulances available at the moment.");
            return;
        }

        // Dispatch ambulance
        availableAmb.setDestinationHospital(bestHospital);
        availableAmb.changeStatus("en route");
        p.updateState(PatientState.TRANSIT);

        // Simulate drop off and register
        bestHospital.registerPatient(p);
        p.updateState(PatientState.ADMITTED);
        System.out.println("Patient " + p.getName() + " admitted to " + bestHospital.getName());
        availableAmb.changeStatus("available");
    }

    /**
     * Finds a hospital with available capacity
     */
    private Hospital findHospitalWithSpace() {
        return hospitals.stream()
                .filter(Hospital::hasSpace)
                .min(Comparator.comparingInt(Hospital::getPatientCount))
                .orElse(null);
    }
}

