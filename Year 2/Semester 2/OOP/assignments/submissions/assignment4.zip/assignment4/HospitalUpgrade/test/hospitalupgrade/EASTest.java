/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package hospitalupgrade;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

public class EASTest {

    public EASTest() {}

    @BeforeClass
    public static void setUpClass() {
        
    }

    @AfterClass
    public static void tearDownClass() {
        
    }

    @Before
    public void setUp() {
        
    }

    @After
    public void tearDown() {
        
    }

    @Test
    public void testRegisterHospitalAndAmbulance() {
        EAS eas = new EAS(new Hospital[]{}, new Ambulance[]{});
        Hospital h = new Hospital("TestHospital", 1);
        Ambulance a = new Ambulance("Amb1");

        eas.registerHospital(h);
        eas.registerAmbulance(a);

        
        assertTrue(true);
    }

    @Test
    public void testRespondToEmergencyAssignsPatient() {
        Hospital h = new Hospital("City_Medical_Center", 2);
        Ambulance a = new Ambulance("Amb1");
        EAS eas = new EAS(new Hospital[]{h}, new Ambulance[]{a});

        Patient p = new Patient("Alice", 6);
        eas.respondToEmergency(p);

        assertEquals(PatientState.ADMITTED, p.getState());
    }

    @Test
    public void testRespondToEmergencyTriggersOverflow() {
        Hospital h = new Hospital("City_Medical_Center", 2);
        Ambulance a = new Ambulance("Amb1");
        EAS eas = new EAS(new Hospital[]{h}, new Ambulance[]{a});

        eas.respondToEmergency(new Patient("Filled", 5));

        Patient p = new Patient("Overflow", 8);
        eas.respondToEmergency(p);

        assertEquals(PatientState.ADMITTED, p.getState());
    }

    @Test
    public void testRespondToEmergencyNoAmbulanceAvailable() {
        Hospital h = new Hospital("City_Medical_Center", 2);
        Ambulance a = new Ambulance("Amb1");
        a.changeStatus("busy"); 

        EAS eas = new EAS(new Hospital[]{h}, new Ambulance[]{a});

        Patient p = new Patient("Bob", 4);
        eas.respondToEmergency(p);

        assertEquals(PatientState.WAITING, p.getState());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testRespondToEmergencyWithNullPatientThrowsException() {
        Hospital h = new Hospital("City_Medical_Center", 2);
        Ambulance a = new Ambulance("Amb1");
        EAS eas = new EAS(new Hospital[]{h}, new Ambulance[]{a});

        eas.respondToEmergency(null); 
    }
}



