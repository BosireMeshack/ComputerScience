/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author meshagwe
 */
public class Library {

    private List<Publication> publications;
    private String mostPopularGenre;
    private Integer retireCount;
    private Integer totalBorrowCount;

    public Library(List<Publication> books) {
        this.publications = books;
        this.mostPopularGenre = null;
        this.retireCount = 0;
        this.totalBorrowCount = 0;
    }

    public void Restock(Publication book) {
        publications.add(book);
    }

    public String Borrow(Publication book) {
        if (book != null && publications.contains(book) && book.getConditionLevel() >= 20) {
            book.setConditionLevel();
            book.setBorrowCount();
            return "Book borrowed successfully";
        }
        return "Book borrowed unsuccessfully";
    }

    public void Retire(Publication bk) {
        if (bk != null && publications.contains(bk) && bk.getConditionLevel() < 20) {
            bk.setCopyCount(0);
            publications.remove(bk);
            retireCount++;
        }
    }

    public Publication mostBorrowed() {
        if (publications.isEmpty()) {
            return null;
        }
        Publication bk = publications.get(0);
        for (Publication plication : publications) {
            if (plication.getBorrowCount() > bk.getBorrowCount()) {
                bk = plication;
            }
        }
        return bk;

    }

    /**
     * Searches for publications that match the specified genre.
     *
     * This method iterates through the list of publications and returns a new
     * list containing only those publications whose genre matches the specified
     * genre. The comparison is case-sensitive.
     *
     * @param genre The genre to search for. Must not be {@code null}.
     * @return A list of publications that match the specified genre. If no
     * publications match the genre, an empty list is returned. The returned
     * list is mutable.
     * @throws NullPointerException If the {@code genre} parameter is
     * {@code null}.
     */
    public List<Publication> searchByGenre(String genre) {
        List<Publication> genreSpecific = new ArrayList<>();
        for (Publication plication : publications) {
            if (genre.equals(plication.getGenre())) {
                genreSpecific.add(plication);
            }
        }
        return genreSpecific;
    }

    public List<Publication> searchByAuthor(String author) {
        List<Publication> authorSpecific = new ArrayList<>();
        for (Publication plication : publications) {
            if (author.equals(plication.getAuthor())) {
                authorSpecific.add(plication);
            }
        }
        return authorSpecific;
    }

    public Boolean checkAvailability(Publication bk) {
        if(bk.getCopyCount() == 0) {
            return false;
        }
        return true;
    }

    public String needRestocking(Publication bk) {
        if (checkAvailability(bk)) {
            return "Not available, need restocking";
        }
        return "{bk.getCopyCount} available";
    }

    public String mostPopularGenre() {
        String mPG = publications.get(0).getGenre();
        int maxBorrowCount = publications.get(0).getBorrowCount();
        for (Publication plication : publications) {
            if (plication.getBorrowCount() > maxBorrowCount) {
                mPG = plication.getGenre();
                maxBorrowCount = plication.getBorrowCount(); 
            }
        }
        this.mostPopularGenre = mPG;
        return mPG;
    }

    public void totalBorrow() {
        totalBorrowCount = 0;
        for (Publication bk : publications) {
            totalBorrowCount = totalBorrowCount + bk.getBorrowCount();
        }

    }

    public Integer getTotalBorrow() {
        return this.totalBorrowCount;
    }
    
    public List<Publication> getBooks()
    {
        return this.publications;
    }
}
