/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package library;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author meshagwe
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Defining the books
        Publication book1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Publication book2 = new Publication("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, 2);
        Publication book3 = new Publication("1984", "George Orwell", "Science Fiction", 1949, 5);
        Publication book4 = new Publication("The Art of War", "Sun Tzu", "History", 500, 1);
        Publication book5 = new Publication("The Art of War", "Sun Tzu", "History", 500, 1);
        
        
        // Initializing an array for the books
        Library library = new Library(new ArrayList<>());
        // Adding the books to the array
        library.Restock(book1);
        library.Restock(book2);
        library.Restock(book3);
        library.Restock(book4);
        library.Restock(book5);
        // Confirming borrowing of a book
        System.out.println("Borrowing 'The Great Gatsby': " + library.Borrow(book1));
        System.out.println("Borrowing 'The Great Gatsby' again: " + library.Borrow(book1));
        System.out.println("Borrowing '1984': " + library.Borrow(book3));
        
        // Simulating wear and tear
        for (int i = 0; i < 85; i++) {
            book1.setConditionLevel(); 
        }
        
        // Retiring a book
        System.out.println("Retiring 'The Great Gatsby':");
        library.Retire(book1);
         
        System.out.println("\nBooks in the 'Fiction' genre:");
        List<Publication> fictionBooks = library.searchByGenre("Fiction");
        
        for (Publication book : fictionBooks) {
            System.out.println(book.getTitle() + " by " + book.getAuthor());
        }
        
        System.out.println("\nBooks by 'George Orwell':");
        List<Publication> orwellBooks = library.searchByAuthor("George Orwell");
        for (Publication book : orwellBooks) {
            System.out.println(book.getTitle() + " by " + book.getAuthor());
        }
        
        // Checks if a book needs restocking
        System.out.println("\nChecking availability of 'The Art of War':");
        System.out.println(library.needRestocking(book4));
        System.out.println(library.needRestocking(book5));
        
        //    System.out.println("\nChecking availability of 'The Art of War':");
        //    System.out.println(library.needRestocking(book4));

        System.out.println("\nMost borrowed book:");
        Publication mostBorrowed = library.mostBorrowed();
        System.out.println(mostBorrowed.getTitle() + " by " + mostBorrowed.getAuthor() + " (Borrowed " + mostBorrowed.getBorrowCount() + " times)");
        
        // Looks for most popular genre
        System.out.println("\nMost popular genre:");
        String popularGenre = library.mostPopularGenre();
        System.out.println(popularGenre);
        
        
        library.totalBorrow();
        System.out.println("\nTotal books borrowed: " + library.getTotalBorrow());
        
    }
    
}
