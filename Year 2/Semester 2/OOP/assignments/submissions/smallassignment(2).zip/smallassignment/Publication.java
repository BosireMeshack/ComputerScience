/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library;

/**
 *
 * @author meshagwe
 */
public class Publication {

    private String title;
    private String author;
    private String genre;
    private Integer publicationYear;
    private Integer copyCount;
    private Integer conditionLevel;
    private Integer borrowCount;

    public Publication(String title, String author, String genre, Integer publicationYear, Integer copyCount) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.publicationYear = publicationYear;
        this.copyCount = copyCount;
        this.borrowCount = 0;
        this.conditionLevel = 100;
    }

    public int getBorrowCount() {
        return this.borrowCount;
    }

    public void setBorrowCount() {
        this.borrowCount++;
    }

    public String getAuthor() {
        return this.author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return this.genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public Integer getCopyCount() {
        return this.copyCount;
    }

    public void setConditionLevel() {
        if (conditionLevel > 0) {
            this.conditionLevel--;
        }
    }

    public Integer getConditionLevel() {
        return this.conditionLevel;
    }

    public void setCopyCount(Integer copyCount) {
        this.copyCount = copyCount;
    }

    public String getTitle() {
        return this.title;
    }

    public void setPublicationYear(Integer publicationYear) {
        this.publicationYear = publicationYear;
    }

    public Integer getPublicationYear() {
        return this.publicationYear;
    }

}
