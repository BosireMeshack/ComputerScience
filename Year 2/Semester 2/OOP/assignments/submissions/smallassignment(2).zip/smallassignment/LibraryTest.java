/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package library;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author meshagwe
 */
public class LibraryTest {
    
    public LibraryTest() {
        
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Restock method, of class Library.
     */
    @Test
    public void testRestock() {
        System.out.println("Restock");
        Publication book = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Library instance = new Library(new ArrayList<>());
        instance.Restock(book);
        
         // Create a new publication to restock
        Publication newBook = new Publication("The Art of War", "Sun Tzu", "History", 500, 1);

          // Get the initial size of the library's collection
        int initialSize = instance.searchByGenre("Fiction").size() + instance.searchByGenre("Science Fiction").size();

        // Restock the new book
        instance.Restock(newBook);

        // Verify that the library's collection size has increased by 1
        int newSize = instance.searchByGenre("Fiction").size() + instance.searchByGenre("Science Fiction").size() + instance.searchByGenre("History").size();
        assertEquals(initialSize + 1, newSize);

        // Verify that the restocked book is in the library's collection
        List<Publication> historyBooks = instance.searchByGenre("History");
        assertTrue(historyBooks.contains(newBook));
    }

    /**
     * Test of Borrow method, of class Library.
     */
    @Test
    public void testBorrow() {
        System.out.println("Borrow");
        Publication book = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Library instance = new Library(new ArrayList<>());
        instance.Restock(book);
       assertEquals("Book borrowed successfully", instance.Borrow(book));
       assertEquals(1, book.getBorrowCount());
        for (int i = 0; i < 85; i++) {
            book.setConditionLevel(); 
        }
       assertEquals("Book borrowed unsuccessfully", instance.Borrow(book));
    }

//    /**
//     * Test of Retire method, of class Library.
//     */
//    @Test
    public void testRetire() {
        System.out.println("Retire");
        Publication bk = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Library instance = new Library(new ArrayList<>());
        instance.Retire(bk);
         for (int i = 0; i < 85; i++) {
            bk.setConditionLevel();
        }
        // TODO review the generated test code and remove the default call to fail.
        instance.Retire(bk);
       // assertEquals(0, bk.getCopyCount());
        assertFalse(instance.searchByGenre("Fiction").contains(bk));
    }

//    /**
//     * Test of mostBorrowed method, of class Library.
//     */
//    @Test
    public void testMostBorrowed() {
        System.out.println("mostBorrowed");
        Publication book1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Publication book2 = new Publication("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, 2);
        Publication book3 = new Publication("1984", "George Orwell", "Science Fiction", 1949, 5);

        // Initialize library and add publications
        Library library = new Library(new ArrayList<>());
        library.Restock(book1);
        library.Restock(book2);
        library.Restock(book3);
        library.Borrow(book1);
        library.Borrow(book1);
        library.Borrow(book2);
        
        Publication result = library.mostBorrowed();
        assertEquals(book1, result);
        // TODO review the generated test code and remove the default call to fail.
       
    }
//
//    /**
//     * Test of searchByGenre method, of class Library.
//     */
//    @Test
    public void testSearchByGenre() {
        System.out.println("searchByGenre");
        Publication book1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Publication book2 = new Publication("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, 2);
        Publication book3 = new Publication("1984", "George Orwell", "Science Fiction", 1949, 5);
        
        String genre = "Fiction";
        Library instance = new Library(new ArrayList<>());
        instance.Restock(book3);
        instance.Restock(book2);
        instance.Restock(book1);
        //List<Publication> expResult = null;
        List<Publication> result = instance.searchByGenre(genre);
        assertEquals(2, result.size());
        assertTrue(result.contains(book1));
        assertTrue(result.contains(book2));
    }
//
//    /**
//     * Test of searchByAuthor method, of class Library.
//     */
    @Test
    public void testSearchByAuthor() {
        System.out.println("searchByAuthor");
        Publication book1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Publication book2 = new Publication("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, 2);
        Publication book3 = new Publication("1984", "George Orwell", "Science Fiction", 1949, 5);
        String author = "George Orwell";
        Library instance = new Library(new ArrayList<>());
        instance.Restock(book3);
        instance.Restock(book2);
        instance.Restock(book1);
        //List<Publication> expResult = null;
        List<Publication> result = instance.searchByAuthor(author);
        assertEquals(1, result.size());
        
    }
//
//    /**
//     * Test of checkAvailability method, of class Library.
//     */
    @Test
    public void testCheckAvailability() {
        System.out.println("checkAvailability");
        Publication book1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Publication book2 = new Publication("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, 2);
        Publication book3 = new Publication("1984", "George Orwell", "Science Fiction", 1949, 5);
        
        Library instance = new Library(new ArrayList<>());
        instance.Restock(book3);
        instance.Restock(book2);
        instance.Restock(book1);
        Boolean expResult = true;
        Boolean result = instance.checkAvailability(book1);
        assertEquals(expResult, result);
        book1.setCopyCount(0);
        assertFalse(instance.checkAvailability(book1));
    }
//
//    /**
//     * Test of needRestocking method, of class Library.
//     */
//    @Test
//    public void testNeedRestocking() {
//        System.out.println("needRestocking");
//        Publication bk = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
//        Library instance = new Library(new ArrayList<>());
//        String expResult = "{bk.getCopyCount} available";
//        String exp2Result = "Not available, need restocking";
//        String result = instance.needRestocking(bk);
//        assertEquals(expResult, result);
////        instance.Retire(bk);
////        assertEquals(exp2Result, result);
       
//    }
//
//    /**
//     * Test of mostPopularGenre method, of class Library.
//     */
    @Test
    public void testMostPopularGenre() {
        System.out.println("mostPopularGenre");
        Publication book1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Publication book2 = new Publication("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, 2);
        Publication book3 = new Publication("1984", "George Orwell", "Science Fiction", 1949, 5);
        
        Library instance = new Library(new ArrayList<>());
        instance.Restock(book3);
        instance.Restock(book2);
        instance.Restock(book1);
        instance.Borrow(book1);
        instance.Borrow(book1);
        instance.Borrow(book2);
        String expResult = "Fiction";
        String result = instance.mostPopularGenre();
        assertEquals(expResult, result);
        
    }

//    /**
//     * Test of totalBorrow method, of class Library.
//     */
    @Test
    public void testTotalBorrow() {
        System.out.println("totalBorrow");
        Publication book1 = new Publication("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 1925, 3);
        Publication book2 = new Publication("To Kill a Mockingbird", "Harper Lee", "Fiction", 1960, 2);
        Publication book3 = new Publication("1984", "George Orwell", "Science Fiction", 1949, 5);
        
        Library instance = new Library(new ArrayList<>());
        instance.Restock(book3);
        instance.Restock(book2);
        instance.Restock(book1);
        instance.Borrow(book1);
        instance.Borrow(book2);
        instance.totalBorrow();
        
        //assertEquals(2, instance.getTotalBorrow());
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
//
//    /**
//     * Test of getTotalBorrow method, of class Library.
//     */
//    @Test
//    public void testGetTotalBorrow() {
//        System.out.println("getTotalBorrow");
//        Library instance = null;
//        Integer expResult = null;
//        Integer result = instance.getTotalBorrow();
//        assertEquals(expResult, result);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
