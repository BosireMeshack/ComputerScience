package warrior;

public class Sword {

    private int maxCombo;
    private int currentCombo;

    public Sword(int maxC) {
        this.maxCombo = maxC;
        currentCombo = 0;
    }

    public int attack() {
        currentCombo = Math.min(currentCombo + 1, maxCombo);
        return calcDamage();
    }

    public void resetCombo() {
        currentCombo = 0;
    }

    public int calcDamage() {
        int base = 5;
        return base + currentCombo * 2;
    }
}
