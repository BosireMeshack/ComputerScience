package warrior;

public class Shield {

    private int maxDurability;
    private int currentDurability;
    private double blockProb;

    public Shield(int maxDur, double prob) {
        maxDurability = maxDur;
        currentDurability = maxDur;
        blockProb = prob;
    }

    public boolean block() {
        double prob = calcBlockProb();
        double randomValue = Math.random();
        if (randomValue < prob) {
            currentDurability = Math.max(0, currentDurability - 1);
            return true;
        }
        return false;
    }

    public void repair() {
        currentDurability = maxDurability;
    }

    public double calcBlockProb() {
        double ratio = currentDurability / maxDurability;
        return blockProb * ratio;
    }
}
