package warrior;

public class Warrior {

    private String name;
    private int hitPoints;
    private Sword sword;
    private Shield shield;

    public Warrior(String n, int hp, Sword swrd, Shield shld) {
        name = n;
        hitPoints = hp;
        sword = swrd;
        shield = shld;
    }

    public void attack(Warrior target) {
        int damage = sword.attack();
        if (!target.shield.block()) {
            target.takeDamage(damage);
        }
    }

    public void shieldBash(Warrior target) {
        sword.resetCombo();
        double bonus = shield.calcBlockProb() * 25;
        int damage = (int) (15.0 + bonus);
        if (!target.shield.block()) {
            target.takeDamage(damage);
        }
    }

    public void repairShield() {
        shield.repair();
    }

    public void takeDamage(int dmg) {
        hitPoints = Math.max(0, hitPoints - dmg);
    }

    public boolean isAlive() {
        return hitPoints > 0;
    }

    public String getName() {
        return name;
    }
}
