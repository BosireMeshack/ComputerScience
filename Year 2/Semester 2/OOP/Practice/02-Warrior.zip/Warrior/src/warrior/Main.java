package warrior;

public class Main {
    public static void main(String[] args) {
        Warrior warriorA = new Warrior("Boromir", 100, new Sword(3), new Shield(10,0.7));
        Warrior warriorB = new Warrior("Lurtz", 120, new Sword(4), new Shield(8, 0.6));

        while(warriorA.isAlive() && warriorB.isAlive()) {
            
            double action = Math.random();
            if(action < 0.6) {
                warriorA.attack(warriorB);
            }
            else if(action < 0.9) {
                warriorA.shieldBash(warriorB);
            }
            else{
                warriorA.repairShield();
            }
            
            if (!warriorB.isAlive()) {
                break;
            }
            
            double action2 = Math.random();
            if(action2 < 0.5) {
                warriorB.attack(warriorA);
            }
            else if(action2 < 0.75) {
                warriorB.shieldBash(warriorA);
            }
            else {
                warriorB.repairShield();
            }
        }
        if (warriorA.isAlive()) {
            System.out.println(warriorA.getName() + " is the winner! Long live "
                    + warriorA.getName() + "!");
        }
        if (warriorB.isAlive()) {
            System.out.println(warriorB.getName() + " is the winner! Long live "
                    + warriorB.getName() + "!");
        }
    }
}
