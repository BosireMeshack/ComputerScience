﻿using System.Reflection.Metadata.Ecma335;

internal class Program
{

    struct LootInf {
        public int lootValue;
        public string lootRegion;
        public string pirateName;

    }

    // Function for minimum selection

    static int miniV(LootInf[] Loots, int n)
    {
        int minind=0;
        for(int j=0; j<n; j++)
        {
            if(Loots[j].lootValue < Loots[minind].lootValue)
            {
                minind = j;
            }
        }
        return minind;
    }
    private static void Main(string[] args)
    {
        string input = Console.ReadLine();
        int n = Convert.ToInt32(input.Split(" ")[0]); // number of lootings
        int t = Convert.ToInt32(input.Split(" ")[1]); // threshold

        LootInf[] Loots = new LootInf[n];

        for (int i=0; i<n; i++)
        {
            string lootinput = Console.ReadLine();
            Loots[i].lootValue = Convert.ToInt32(lootinput.Split(" ")[0]);
            Loots[i].lootRegion = lootinput.Split(" ")[1];
            Loots[i].pirateName = lootinput.Split(" ")[2];
        }
        // Confirm the right inputs
        //   for (int i=0; i<n; i++)
        // {
           
        //    Console.WriteLine(Loots[i].lootValue + " " + Loots[i].lootRegion + " " + Loots[i].pirateName);
           
        // }
        // Name of pirate with lowest value of single loot
        //a
        Console.WriteLine(Loots[miniV(Loots, n)].pirateName);
        

    }
}