﻿internal class Program
{

    static int minV(int [,] performances, int n, int m)
    {
        int minvalue=performances[0,0];

        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                if(performances[i,j]<minvalue)
                {
                    minvalue = performances[i,j];
                }
            }
        }
        return minvalue;
    }

    static int sumV(int [,] performances, int n, int m)
     {
        int sum=0;

        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
 
              
                    sum += performances[i,j];
                
            }
        }
        return sum;
    }
    private static void Main(string[] args)
    {
        string input = Console.ReadLine();

        int n = Convert.ToInt32(input.Split(" ")[0]);
        int m = Convert.ToInt32(input.Split(" ")[1]);

        int[,] performances = new int[n,m];

        for (int i=0; i<n; i++)
        {
            string line = Console.ReadLine();
            for(int j=0; j<m; j++)
            {
                performances[i,j] = Convert.ToInt32(line.Split(" ")[j]);
            }
        } 

        //confirm input
        // for (int i=0; i<n; i++)
        // {
            
        //     for(int j=0; j<m; j++)
        //     {
        //         Console.Write(performances[i,j]+ " ");
        //     }
        //     Console.WriteLine();
        // } 
        // a 
        //Console.WriteLine(minV(performances, n,m));

        //b
        Console.WriteLine(sumV(performances, n, m));
    }
}